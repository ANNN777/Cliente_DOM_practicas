//1. definir nodos y obtener hijos de la clase small
let nodo_imagen = document.getElementById("pulgarPositivo");
let nodo_numeroA = document.getElementById("h1");

//let nodo_numero1 = document.querySelector("h2");

//2. Declaro los eventos
    nodo_imagen.addEventListener("click", cambiar_color1);

function cambiar_color1() {

    let imgPulgar = nodo_imagen.getAttribute("src");
    let contadorPulgar=parseInt(nodo_numeroA.textContent);//Parseamos el contador a número entero. 

    if (imgPulgar === "img/gusta2.png"){
        nodo_imagen.setAttribute("src","img/gusta.png");
       contadorPulgar++;
       nodo_numeroA.textContent=contadorPulgar;

    } else {
        nodo_imagen.setAttribute("src","img/gusta2.png");
        contadorPulgar--;
        nodo_numeroA.textContent=contadorPulgar;
    }
}

//2. PulgarNegativo
let nodo_imagen2 = document.getElementById("pulgarNegativo");
let nodo_numeroB = document.getElementById("h2");

//2. Declaro los eventos
nodo_imagen2.addEventListener("click", cambiar_color2);

function cambiar_color2() {

    let imgPulgar2 = nodo_imagen2.getAttribute("src");
    let contadorPulgar2=parseInt(nodo_numeroB.textContent);//Parseamos el contador a número entero. 
    
    console.log(imgPulgar2);
    if (imgPulgar2 === "img/disgusto2.png"){
        nodo_imagen2.setAttribute("src","img/disgusto.png");
        contadorPulgar2--;
        nodo_numeroB.textContent=contadorPulgar2;
    } else {
        nodo_imagen2.setAttribute("src","img/disgusto2.png");
        contadorPulgar2++;
        nodo_numeroB.textContent=contadorPulgar2;
    }
}

//5. generar Items
let nodo_boton = document.getElementById("btn_Contactar");
let nodo_inputs = document.className("inputs");

nodo_boton.addEventListener("click", generarInputs);

function generarInputs(){

    let numero = nodo_input.createElement("input");
    console.log(numero);

    numero.setAttribute("type","text");

    nodo_inputs.append(numero);

}

