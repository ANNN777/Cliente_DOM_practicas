//1.Definir los nodos
let nodo_lista = document.querySelectorAll("li");

//2. declarar el evento

for (const element of nodo_lista) {

    element.addEventListener("click", alternar_clase);
    
}

function alternar_clase(e){

    let clase = e.target.className;

    if (clase==="") {
        e.target.className="done";

    } else {
        e.target.className="";
    }

}

//ANTONIO JOSÉ MÉRIDA RODRÍGUEZ. 2º DAW//
